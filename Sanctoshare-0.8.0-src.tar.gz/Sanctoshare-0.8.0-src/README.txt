

   Copyright (c) 2015, Al Poole <netstar@gmail.com>
   All rights reserved. 

   USAGE
  
   Run server.js on remote machine with Node.js.
   
   ./sanctoshare <hostname> <watch dir>
 
   e.g.
   
   ./sanctoshare haxlab.org /root/Pictures
  
   Major Changes:

   *  As of version 0.8.0.0 our server uses node.js.

   *  As of version 0.8.0.0 we revert to Simplified BSD License.

   *  As of version 0.6.10.0 we do parallel tasks better!

   *  As of version 0.6.8.4 we introduced HTTP/1.1 with SSL.

   THANKS

   Thanks to Sam Watkins, Chris Rahm, Jason Pierce, 
   Ed Poole, Graham Anderson and Mike Parfitt.


   CONTACT

   Send us an e-mail with your questions, problems, suggestions or to arrange a
   nice sit down, cup of tea and a biscuit!

   E-mail: netstar@gmail.com
   Web: http://haxlab.org

   DONATIONS

   We accept donations of cash, food, beer and computer equipment!

   No seagulls were harmed during the production of SanctoShare.


   SALUTATION

   Cheerio! Cheerio! Cheerio!

